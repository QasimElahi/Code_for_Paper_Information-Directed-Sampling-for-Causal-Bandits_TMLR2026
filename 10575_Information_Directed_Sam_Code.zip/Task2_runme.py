"""
Task 2 experiment for Fig. 3(b).

Causal graph:
    C -> X1
    C -> X2
    X1 -> X2
    Z -> X2
    Z -> Y
    X2 -> Y

Z is non-manipulable and C in {0,1,2} is observed before action selection.

POMIS-induced actions:
    do(X1=0), do(X1=1), do(X2=0), do(X2=1)

Methods:
    1. Contextual UCB on the POMIS arms.
    2. Context-specific Bernoulli Thompson Sampling on the POMIS arms.
    3. Causal inverse-variance Thompson-sampling baseline inspired by Lee & Bareinboim (2019).
    4. Proposed causal Thompson Sampling using the shared-CPT posterior.
    5. Proposed IDS using Monte Carlo estimates from the shared-CPT posterior.

Baseline implementation:
    - The causal inverse-variance baseline combines a direct context/action-specific
      Bernoulli estimate with a shared-CPT causal estimate using inverse-variance
      weighting, then moment-matches the result to a Beta distribution and takes
      one Thompson draw per arm.
    - This is an intentionally modest baseline inspired by the estimator-sharing
      motivation of Lee & Bareinboim (2019); it is not claimed to reproduce their
      full generic z^2-ID/bMVWA procedure.


Dependencies: numpy, matplotlib.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import matplotlib.pyplot as plt


# Task-2 action set

DO_X1_0 = 0
DO_X1_1 = 1
DO_X2_0 = 2
DO_X2_1 = 3

K = 4
N_CONTEXTS = 3

ACTION_NAMES = (
    "do(X1=0)",
    "do(X1=1)",
    "do(X2=0)",
    "do(X2=1)",
)

ACTIONS = (
    (0, None),
    (1, None),
    (None, 0),
    (None, 1),
)


# Fixed reproducible Task-2 SCM

@dataclass(frozen=True)
class Task2SCM:
    """Task-2 SCM with three-valued context C and binary Z,X1,X2,Y."""

    p_context: np.ndarray
    p_z1: float
    p_x1_given_c: np.ndarray
    p_x2_given_czx1: np.ndarray
    p_y1_given_x2z: np.ndarray

    @classmethod
    def fixed(cls) -> "Task2SCM":
        """Fixed three-context SCM used by every method and trial."""
        return cls(
            p_context=np.array(
                [0.2638117514, 0.3618275639, 0.3743606847],
                dtype=float,
            ),
            p_z1=0.6270600764,
            p_x1_given_c=np.array(
                [0.2895725473, 0.1108342648, 0.1115481692],
                dtype=float,
            ),
            p_x2_given_czx1=np.array(
                [
                    [
                        [0.9241888693, 0.8739701462],
                        [0.0612447247, 0.7169166511],
                    ],
                    [
                        [0.6815143210, 0.2183190710],
                        [0.3463960432, 0.8775868842],
                    ],
                    [
                        [0.2757739657, 0.7334004268],
                        [0.8266781099, 0.0765423723],
                    ],
                ],
                dtype=float,
            ),
            p_y1_given_x2z=np.array(
                [
                    [0.7264079228, 0.1002033444],
                    [0.1607285977, 0.9202830276],
                ],
                dtype=float,
            ),
        )

    @classmethod
    def random(cls, seed: int) -> "Task2SCM":
        """Generate a graph-consistent three-context SCM."""
        rng = np.random.default_rng(seed)
        return cls(
            p_context=rng.dirichlet(np.ones(N_CONTEXTS)),
            p_z1=float(rng.beta(1.0, 1.0)),
            p_x1_given_c=rng.beta(
                1.0,
                1.0,
                size=N_CONTEXTS,
            ),
            p_x2_given_czx1=rng.beta(
                1.0,
                1.0,
                size=(N_CONTEXTS, 2, 2),
            ),
            p_y1_given_x2z=rng.beta(
                1.0,
                1.0,
                size=(2, 2),
            ),
        )

    def arm_means(self, context: int) -> np.ndarray:
        """Compute all four intervention means exactly for C=context."""
        pz = np.array(
            [1.0 - self.p_z1, self.p_z1],
            dtype=float,
        )
        out = np.zeros(K, dtype=float)

        for action, (fix_x1, fix_x2) in enumerate(ACTIONS):
            mu = 0.0

            for z in (0, 1):
                if fix_x1 is None:
                    px1_1 = self.p_x1_given_c[context]
                    x1_values = (
                        (0, 1.0 - px1_1),
                        (1, px1_1),
                    )
                else:
                    x1_values = ((fix_x1, 1.0),)

                for x1, wx1 in x1_values:
                    if fix_x2 is None:
                        px2_1 = self.p_x2_given_czx1[
                            context,
                            z,
                            x1,
                        ]
                        x2_values = (
                            (0, 1.0 - px2_1),
                            (1, px2_1),
                        )
                    else:
                        x2_values = ((fix_x2, 1.0),)

                    for x2, wx2 in x2_values:
                        mu += (
                            pz[z]
                            * wx1
                            * wx2
                            * self.p_y1_given_x2z[x2, z]
                        )

            out[action] = mu

        return out

    def sample_context(self, rng: np.random.Generator) -> int:
        """Sample pre-intervention context C in {0,1,2}."""
        return int(
            rng.choice(
                N_CONTEXTS,
                p=self.p_context,
            )
        )

    def sample(
        self,
        action: int,
        context: int,
        rng: np.random.Generator,
    ) -> Tuple[int, int, int, int, int]:
        """Generate one complete sample (C,Z,X1,X2,Y) under the action."""
        fix_x1, fix_x2 = ACTIONS[action]

        z = int(rng.random() < self.p_z1)

        if fix_x1 is None:
            x1 = int(
                rng.random()
                < self.p_x1_given_c[context]
            )
        else:
            x1 = fix_x1

        if fix_x2 is None:
            x2 = int(
                rng.random()
                < self.p_x2_given_czx1[
                    context,
                    z,
                    x1,
                ]
            )
        else:
            x2 = fix_x2

        y = int(
            rng.random()
            < self.p_y1_given_x2z[x2, z]
        )

        return context, z, x1, x2, y


# Shared-CPT posterior used by the causal methods

class CPTPosterior:
    """
    Independent Beta priors/posteriors for all Bernoulli CPT rows.

    A local CPT row is updated only when its variable was not intervened on.
    This is the truncated-factorization likelihood used in the paper.
    """

    def __init__(self, prior: float = 1.0) -> None:
        self.c_counts = np.full(
            N_CONTEXTS,
            prior,
            dtype=float,
        )

        self.z_alpha = prior
        self.z_beta = prior

        self.x1_alpha = np.full(
            N_CONTEXTS,
            prior,
            dtype=float,
        )
        self.x1_beta = np.full(
            N_CONTEXTS,
            prior,
            dtype=float,
        )

        self.x2_alpha = np.full(
            (N_CONTEXTS, 2, 2),
            prior,
            dtype=float,
        )
        self.x2_beta = np.full(
            (N_CONTEXTS, 2, 2),
            prior,
            dtype=float,
        )

        self.y_alpha = np.full((2, 2), prior, dtype=float)
        self.y_beta = np.full((2, 2), prior, dtype=float)

    def observe_context(self, c: int) -> None:
        """
        Incorporate the currently observed context into its own CPT posterior.

        Under the independent-CPT prior used here, this does not alter the other
        mechanism posteriors, but it keeps the timing aligned with observing C
        before action selection.
        """
        self.c_counts[c] += 1.0

    def update_after_action(
        self,
        action: int,
        c: int,
        z: int,
        x1: int,
        x2: int,
        y: int,
    ) -> None:
        """Update all non-intervened post-action mechanisms."""
        if z == 1:
            self.z_alpha += 1.0
        else:
            self.z_beta += 1.0

        fix_x1, fix_x2 = ACTIONS[action]

        if fix_x1 is None:
            if x1 == 1:
                self.x1_alpha[c] += 1.0
            else:
                self.x1_beta[c] += 1.0

        if fix_x2 is None:
            if x2 == 1:
                self.x2_alpha[c, z, x1] += 1.0
            else:
                self.x2_beta[c, z, x1] += 1.0

        if y == 1:
            self.y_alpha[x2, z] += 1.0
        else:
            self.y_beta[x2, z] += 1.0

    def sample_arm_means(
        self,
        rng: np.random.Generator,
        n: int,
        context: int,
    ) -> np.ndarray:
        """
        Draw n posterior CPT samples and return all four action means.

        Output shape is (n,4).
        """
        pz1 = rng.beta(self.z_alpha, self.z_beta, size=n)

        px1_1 = rng.beta(
            self.x1_alpha[context],
            self.x1_beta[context],
            size=n,
        )

        px2_1 = np.empty((n, 2, 2), dtype=float)
        for z in (0, 1):
            for x1 in (0, 1):
                px2_1[:, z, x1] = rng.beta(
                    self.x2_alpha[context, z, x1],
                    self.x2_beta[context, z, x1],
                    size=n,
                )

        py1 = np.empty((n, 2, 2), dtype=float)
        for x2 in (0, 1):
            for z in (0, 1):
                py1[:, x2, z] = rng.beta(
                    self.y_alpha[x2, z],
                    self.y_beta[x2, z],
                    size=n,
                )

        out = np.zeros((n, K), dtype=float)
        pz = (1.0 - pz1, pz1)

        for action, (fix_x1, fix_x2) in enumerate(ACTIONS):
            mu = np.zeros(n, dtype=float)

            for z in (0, 1):
                if fix_x1 is None:
                    x1_values = (
                        (0, 1.0 - px1_1),
                        (1, px1_1),
                    )
                else:
                    x1_values = ((fix_x1, np.ones(n)),)

                for x1, wx1 in x1_values:
                    if fix_x2 is None:
                        q = px2_1[:, z, x1]
                        x2_values = (
                            (0, 1.0 - q),
                            (1, q),
                        )
                    else:
                        x2_values = ((fix_x2, np.ones(n)),)

                    for x2, wx2 in x2_values:
                        mu += (
                            pz[z]
                            * wx1
                            * wx2
                            * py1[:, x2, z]
                        )

            out[:, action] = mu

        return out




# Helpers

def _argmax_random_tie(
    values: np.ndarray,
    rng: np.random.Generator,
) -> int:
    maximum = np.max(values)
    idx = np.flatnonzero(
        np.isclose(values, maximum, rtol=0.0, atol=1e-14)
    )
    return int(rng.choice(idx))


def _record_regret(
    cumulative: float,
    action: int,
    true_means: np.ndarray,
) -> float:
    return cumulative + float(
        np.max(true_means) - true_means[action]
    )


def _print_progress(name: str, trial: int, trials: int) -> None:
    if trials >= 20 and (
        (trial + 1) % max(1, trials // 10) == 0
        or trial + 1 == trials
    ):
        print(f"[{name}] {trial + 1}/{trials} trials")




# Baseline 1: contextual UCB

def run_ucb(
    scm: Task2SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    true_means = np.stack(
        [
            scm.arm_means(c)
            for c in range(N_CONTEXTS)
        ]
    )
    out = np.zeros((trials, horizon), dtype=float)

    for trial in range(trials):
        rng = np.random.default_rng(seed + trial)

        pulls = np.zeros((N_CONTEXTS, K), dtype=int)
        reward_sum = np.zeros((N_CONTEXTS, K), dtype=float)
        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(rng)

            untried = np.flatnonzero(pulls[c] == 0)
            if len(untried) > 0:
                action = int(untried[0])
            else:
                empirical = reward_sum[c] / pulls[c]
                bonus = np.sqrt(
                    2.0 * np.log(t + 2.0) / pulls[c]
                )
                action = _argmax_random_tie(
                    empirical + bonus,
                    rng,
                )

            _, z, x1, x2, y = scm.sample(action, c, rng)

            pulls[c, action] += 1
            reward_sum[c, action] += y

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )
            out[trial, t] = cumulative_regret

        _print_progress("UCB", trial, trials)

    return out


# Baseline 2: context-specific Bernoulli Thompson Sampling

def run_bernoulli_ts(
    scm: Task2SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    true_means = np.stack(
        [
            scm.arm_means(c)
            for c in range(N_CONTEXTS)
        ]
    )
    out = np.zeros((trials, horizon), dtype=float)

    for trial in range(trials):
        rng = np.random.default_rng(seed + trial)

        alpha = np.ones((N_CONTEXTS, K), dtype=float)
        beta = np.ones((N_CONTEXTS, K), dtype=float)
        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(rng)

            theta = rng.beta(alpha[c], beta[c])
            action = _argmax_random_tie(theta, rng)

            _, z, x1, x2, y = scm.sample(action, c, rng)

            alpha[c, action] += y
            beta[c, action] += 1 - y

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )
            out[trial, t] = cumulative_regret

        _print_progress("Bernoulli TS", trial, trials)

    return out


# Baseline 3: causal inverse-variance TS inspired by Lee & Bareinboim (2019)

def _beta_from_mean_variance(
    mean: float,
    var: float,
) -> Tuple[float, float]:
    eps = 1e-8
    m = float(np.clip(mean, eps, 1.0 - eps))
    vmax = m * (1.0 - m)
    v = float(np.clip(var, eps, vmax * (1.0 - 1e-8)))

    concentration = m * (1.0 - m) / v - 1.0
    concentration = max(concentration, 2.0)

    return (
        m * concentration,
        (1.0 - m) * concentration,
    )


def run_causal_inverse_variance_ts(
    scm: Task2SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    """
    Causal inverse-variance Thompson-sampling comparator inspired by
    Lee and Bareinboim (2019). It combines a direct context-action
    estimate with an auxiliary shared-CPT causal estimate using
    inverse-variance weighting, followed by Beta moment matching.
    """
    baseline_cpt_samples = 50

    true_means = np.stack(
        [
            scm.arm_means(c)
            for c in range(N_CONTEXTS)
        ]
    )
    out = np.zeros((trials, horizon), dtype=float)

    for trial in range(trials):
        rng = np.random.default_rng(seed + trial)

        alpha = np.ones((N_CONTEXTS, K), dtype=float)
        beta = np.ones((N_CONTEXTS, K), dtype=float)

        causal = CPTPosterior(prior=0.5)

        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(rng)
            causal.observe_context(c)

            causal_draws = causal.sample_arm_means(
                rng,
                baseline_cpt_samples,
                c,
            )
            causal_mean = causal_draws.mean(axis=0)
            causal_var = causal_draws.var(axis=0, ddof=1)

            theta = np.empty(K, dtype=float)

            for action in range(K):
                direct_mean = (
                    alpha[c, action]
                    / (alpha[c, action] + beta[c, action])
                )
                direct_var = (
                    direct_mean
                    * (1.0 - direct_mean)
                    / (
                        alpha[c, action]
                        + beta[c, action]
                        + 1.0
                    )
                )

                v_direct = max(float(direct_var), 1e-10)
                v_causal = max(float(causal_var[action]), 1e-10)

                combined_mean = (
                    causal_mean[action] / v_causal
                    + direct_mean / v_direct
                ) / (
                    1.0 / v_direct
                    + 1.0 / v_causal
                )

                combined_var = 1.0 / (
                    1.0 / v_direct
                    + 1.0 / v_causal
                )

                aa, bb = _beta_from_mean_variance(
                    float(combined_mean),
                    float(combined_var),
                )
                theta[action] = rng.beta(aa, bb)

            action = _argmax_random_tie(theta, rng)

            _, z, x1, x2, y = scm.sample(action, c, rng)

            alpha[c, action] += y
            beta[c, action] += 1 - y

            causal.update_after_action(
                action,
                c,
                z,
                x1,
                x2,
                y,
            )

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )
            out[trial, t] = cumulative_regret

        _print_progress(
            "Causal inverse-variance TS",
            trial,
            trials,
        )

    return out


# Proposed causal Thompson Sampling

def run_causal_ts(
    scm: Task2SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    true_means = np.stack(
        [
            scm.arm_means(c)
            for c in range(N_CONTEXTS)
        ]
    )
    out = np.zeros((trials, horizon), dtype=float)

    for trial in range(trials):
        rng = np.random.default_rng(seed + trial)

        posterior = CPTPosterior()
        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(rng)
            posterior.observe_context(c)

            sampled_means = posterior.sample_arm_means(
                rng,
                1,
                c,
            )[0]

            action = _argmax_random_tie(
                sampled_means,
                rng,
            )

            _, z, x1, x2, y = scm.sample(
                action,
                c,
                rng,
            )

            posterior.update_after_action(
                action,
                c,
                z,
                x1,
                x2,
                y,
            )

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )
            out[trial, t] = cumulative_regret

        _print_progress("Causal TS", trial, trials)

    return out




def _mc_delta_and_information(
    mu_samples: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Monte Carlo estimates of expected regret and
    g_t(a|c)=I(A^*(c);Y_a|C=c) for binary rewards.
    """
    n, k = mu_samples.shape
    a_star = np.argmax(mu_samples, axis=1)
    best_mu = mu_samples[np.arange(n), a_star]

    delta = np.mean(best_mu[:, None] - mu_samples, axis=0)
    delta = np.clip(delta, 0.0, 1.0)

    p_star = np.bincount(a_star, minlength=k).astype(float) / n
    info = np.zeros(k, dtype=float)

    for action in range(k):
        mu_a = mu_samples[:, action]

        joint_y1 = (
            np.bincount(
                a_star,
                weights=mu_a,
                minlength=k,
            ).astype(float)
            / n
        )
        joint_y0 = p_star - joint_y1

        p_y1 = float(np.sum(joint_y1))
        p_y0 = 1.0 - p_y1

        g = 0.0
        for j in range(k):
            if p_star[j] <= 0.0:
                continue

            q1 = joint_y1[j]
            if q1 > 0.0 and p_y1 > 0.0:
                g += q1 * math.log(
                    q1 / (p_star[j] * p_y1)
                )

            q0 = joint_y0[j]
            if q0 > 0.0 and p_y0 > 0.0:
                g += q0 * math.log(
                    q0 / (p_star[j] * p_y0)
                )

        info[action] = max(g, 0.0)

    info = np.clip(
        info,
        0.0,
        math.log(2.0),
    )
    return delta, info

def _ids_ratio(regret: float, info: float) -> float:
    if regret <= 1e-15:
        return 0.0
    if info <= 1e-15:
        return math.inf
    return regret * regret / info


def _ids_distribution(
    delta: np.ndarray,
    info: np.ndarray,
) -> np.ndarray:
    """
    Minimize (pi^T Delta)^2 / (pi^T g).

    For finite-action IDS, an optimum can be taken with support on at most two
    actions, so all one- and two-action supports are checked.
    """
    k = len(delta)

    best_ratio = math.inf
    best = None

    for i in range(k):
        ratio = _ids_ratio(
            float(delta[i]),
            float(info[i]),
        )

        if ratio < best_ratio:
            best_ratio = ratio
            best = (i, i, 1.0)

        for j in range(i + 1, k):
            a = float(delta[i] - delta[j])
            b = float(delta[j])
            c = float(info[i] - info[j])
            d = float(info[j])

            candidates = [0.0, 1.0]

            if abs(a * c) > 1e-15:
                lam = (
                    c * b - 2.0 * a * d
                ) / (a * c)
                if 0.0 < lam < 1.0:
                    candidates.append(lam)

            if abs(a) > 1e-15:
                lam0 = -b / a
                if 0.0 < lam0 < 1.0:
                    candidates.append(lam0)

            for lam in candidates:
                expected_regret = (
                    lam * delta[i]
                    + (1.0 - lam) * delta[j]
                )
                expected_info = (
                    lam * info[i]
                    + (1.0 - lam) * info[j]
                )

                ratio = _ids_ratio(
                    float(expected_regret),
                    float(expected_info),
                )

                if ratio < best_ratio:
                    best_ratio = ratio
                    best = (i, j, float(lam))

    if best is None or not np.isfinite(best_ratio):
        p = np.zeros(k, dtype=float)
        p[int(np.argmin(delta))] = 1.0
        return p

    i, j, lam = best

    p = np.zeros(k, dtype=float)
    p[i] += lam
    p[j] += 1.0 - lam

    return p / p.sum()


def run_ids(
    scm: Task2SCM,
    trials: int,
    horizon: int,
    seed: int,
    posterior_samples: int,
) -> np.ndarray:
    true_means = np.stack(
        [
            scm.arm_means(c)
            for c in range(N_CONTEXTS)
        ]
    )
    out = np.zeros((trials, horizon), dtype=float)

    for trial in range(trials):
        rng = np.random.default_rng(seed + trial)

        posterior = CPTPosterior()
        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(rng)
            posterior.observe_context(c)

            mu_samples = posterior.sample_arm_means(
                rng,
                posterior_samples,
                c,
            )
            delta_hat, info_hat = _mc_delta_and_information(
                mu_samples
            )

            pi = _ids_distribution(
                delta_hat,
                info_hat,
            )

            action = int(
                rng.choice(K, p=pi)
            )

            _, z, x1, x2, y = scm.sample(
                action,
                c,
                rng,
            )

            posterior.update_after_action(
                action,
                c,
                z,
                x1,
                x2,
                y,
            )

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )
            out[trial, t] = cumulative_regret

        _print_progress("IDS", trial, trials)

    return out


# Plotting

def _plot_curve(
    ax,
    data: np.ndarray,
    label: str,
    color: str,
    marker: str,
    horizon: int,
) -> None:
    mean = np.mean(data, axis=0)
    sd = np.std(data, axis=0, ddof=1)
    se = sd / np.sqrt(data.shape[0])

    x = np.arange(1, horizon + 1)
    lower = np.maximum(0.0, mean - 1.96 * se)
    upper = mean + 1.96 * se

    mark_every = max(1, horizon // 10)

    ax.plot(
        x,
        mean,
        label=label,
        color=color,
        marker=marker,
        markevery=mark_every,
        markersize=6.5,
        linewidth=2.0,
        markeredgewidth=1.2,
        markerfacecolor="none" if marker != "*" else color,
    )

    ax.fill_between(
        x,
        lower,
        upper,
        color=color,
        alpha=0.16,
        linewidth=0,
    )


def make_figure(
    results: dict,
    horizon: int,
) -> None:
    export_dpi = 600
    fig_width = 3200 / export_dpi
    fig_height = 2500 / export_dpi

    fig, ax = plt.subplots(
        figsize=(fig_width, fig_height),
        dpi=export_dpi,
    )

    _plot_curve(
        ax,
        results["ucb"],
        "UCB on POMISs",
        "#B33F40",
        "^",
        horizon,
    )

    _plot_curve(
        ax,
        results["ts"],
        "Bernoulli TS on POMISs",
        "#0177B3",
        "s",
        horizon,
    )

    _plot_curve(
        ax,
        results["causal_baseline"],
        "Causal inverse-variance TS",
        "#0000CC",
        "*",
        horizon,
    )

    _plot_curve(
        ax,
        results["causal_ts"],
        "TS for Causal Bandits with Non-manipulable Variables",
        "#48A14D",
        "o",
        horizon,
    )

    _plot_curve(
        ax,
        results["ids"],
        "IDS for Causal Bandits with Non-manipulable Variables",
        "#D100D1",
        "D",
        horizon,
    )

    ax.set_xlim(0, horizon)
    ax.set_ylim(bottom=0)

    ax.set_xlabel(
        "Time",
        fontsize=12.5,
    )
    ax.set_ylabel(
        "Mean Cumulative Regret",
        fontsize=12.5,
    )

    ax.tick_params(
        axis="both",
        which="major",
        labelsize=10.5,
        width=1.0,
        length=4.0,
    )

    for spine in ax.spines.values():
        spine.set_linewidth(1.0)

    ax.grid(
        True,
        alpha=0.28,
        linewidth=0.7,
    )

    ax.legend(
        fontsize=8.0,
        loc="upper left",
        frameon=True,
        framealpha=0.95,
        borderpad=0.6,
        labelspacing=0.45,
        handlelength=2.2,
        handletextpad=0.6,
    )

    fig.subplots_adjust(
        left=0.145,
        right=0.985,
        bottom=0.155,
        top=0.975,
    )

    output_file = "task2_fig3b.png"

    fig.savefig(
        output_file,
        dpi=export_dpi,
        facecolor="white",
        edgecolor="none",
    )

    print(
        f"Saved publication figure to: "
        f"{output_file} (3200 x 2500 px, 600 dpi)"
    )

    plt.show()


# Experiment settings

TRIALS = 500
HORIZON = 5000

IDS_SAMPLES = 1000


def main() -> None:
    if TRIALS < 2:
        raise ValueError(
            "Use at least 2 trials so the confidence interval is defined."
        )
    if HORIZON < 1:
        raise ValueError(
            "HORIZON must be positive."
        )
    if IDS_SAMPLES < 1:
        raise ValueError(
            "IDS_SAMPLES must be positive."
        )

    scm = Task2SCM.fixed()

    true_means = np.stack(
        [
            scm.arm_means(c)
            for c in range(N_CONTEXTS)
        ]
    )

    print(
        "Task 2: "
        "C -> X1, C -> X2, X1 -> X2, "
        "Z -> X2, Z -> Y, X2 -> Y; "
        "Z is non-manipulable and C is context"
    )

    print(
        "SCM: fixed structured SCM shared by all methods and trials"
    )
    print(f"Trials: {TRIALS}, horizon: {HORIZON}")
    print(f"IDS posterior samples per round: {IDS_SAMPLES}")

    print(f"P(C) = {scm.p_context}")
    print(f"P(Z=1) = {scm.p_z1:.8f}")

    print(
        "P(X1=1 | C=c), c=0,1,2:"
    )
    print(scm.p_x1_given_c)

    print(
        "P(X2=1 | C,Z,X1), indexed [C,Z,X1]:"
    )
    print(scm.p_x2_given_czx1)

    print(
        "P(Y=1 | X2,Z), rows X2=0,1; columns Z=0,1:"
    )
    print(scm.p_y1_given_x2z)

    for c in range(N_CONTEXTS):
        print(
            f"\nTrue action means for C={c}:"
        )
        for name, mu in zip(
            ACTION_NAMES,
            true_means[c],
        ):
            print(
                f"  {name:10s}: {mu:.8f}"
            )

        optimal = int(
            np.argmax(true_means[c])
        )
        print(
            "Optimal arm for "
            f"C={c}: {ACTION_NAMES[optimal]}"
        )

    print()

    results = {
        "ucb": run_ucb(
            scm,
            TRIALS,
            HORIZON,
            seed=1_000_000,
        ),
        "ts": run_bernoulli_ts(
            scm,
            TRIALS,
            HORIZON,
            seed=2_000_000,
        ),
        "causal_baseline": run_causal_inverse_variance_ts(
                scm,
                TRIALS,
                HORIZON,
                seed=3_000_000,
            ),
        "causal_ts": run_causal_ts(
                scm,
                TRIALS,
                HORIZON,
                seed=4_000_000,
            ),
        "ids": run_ids(
            scm,
            TRIALS,
            HORIZON,
            seed=5_000_000,
            posterior_samples=IDS_SAMPLES,
        ),
    }

    make_figure(
        results,
        HORIZON,
    )

    

if __name__ == "__main__":
    main()
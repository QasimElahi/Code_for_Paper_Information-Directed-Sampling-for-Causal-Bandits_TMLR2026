"""Task 3 experiment for Fig. 3(c).

Causal graph:
    Z1 -> X1 -> Y
    Z1 -> Y
    Z2 -> X3 -> X2 -> Y
    Z2 -> Y
    C  -> X3
    C  -> Y

Z1 and Z2 are non-manipulable. C in {0,1,2} is observed before action selection.

POMIS-induced actions:
    do()
    do(X1=0), do(X1=1)
    do(X2=0), do(X2=1)
    do(X1=0,X2=0), do(X1=0,X2=1)
    do(X1=1,X2=0), do(X1=1,X2=1)

Methods:
    1. Contextual UCB on the POMIS arms.
    2. Context-specific Bernoulli Thompson Sampling on the POMIS arms.
    3. Causal inverse-variance Thompson-sampling baseline inspired by
       Lee & Bareinboim (2019).
    4. Proposed causal Thompson Sampling using the shared-CPT posterior.
    5. Proposed IDS using Monte Carlo estimates from the shared-CPT posterior.

Implementation separation:
    - The causal inverse-variance baseline combines a direct context/action
      Bernoulli estimate with an auxiliary shared-CPT causal estimate using
      inverse-variance weighting, then moment-matches to a Beta distribution
      and takes one Thompson draw per arm.
    - This is the same comparator format used in Tasks 1 and 2. It is inspired
      by Lee & Bareinboim (2019), but is not claimed to reproduce their full
      generic z^2-ID/bMVWA procedure.
    - Proposed causal TS uses one posterior draw per round, while IDS uses
      its own Monte Carlo posterior samples for its information objective.


Dependencies: numpy, matplotlib.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import matplotlib.pyplot as plt


# Task-3 action set

K = 9
N_CONTEXTS = 3

OBS = 0
DO_X1_0 = 1
DO_X1_1 = 2
DO_X2_0 = 3
DO_X2_1 = 4
DO_X1_0_X2_0 = 5
DO_X1_0_X2_1 = 6
DO_X1_1_X2_0 = 7
DO_X1_1_X2_1 = 8

ACTIONS = (
    (None, None),
    (0, None),
    (1, None),
    (None, 0),
    (None, 1),
    (0, 0),
    (0, 1),
    (1, 0),
    (1, 1),
)

ACTION_NAMES = (
    "do()",
    "do(X1=0)",
    "do(X1=1)",
    "do(X2=0)",
    "do(X2=1)",
    "do(X1=0,X2=0)",
    "do(X1=0,X2=1)",
    "do(X1=1,X2=0)",
    "do(X1=1,X2=1)",
)


# Fixed reproducible Task-3 SCM

@dataclass(frozen=True)
class Task3SCM:
    p_context: np.ndarray
    p_z1_1: float
    p_z2_1: float
    p_x1_given_z1: np.ndarray
    p_x3_given_cz2: np.ndarray
    p_x2_given_x3: np.ndarray
    p_y1_given_cz1z2x1x2: np.ndarray

    @classmethod
    def fixed(cls) -> "Task3SCM":
        """Fixed Task-3 SCM used by every method and trial."""
        return cls(
            p_context=np.array([0.3947065369, 0.2930579390, 0.3122355241], dtype=float),
            p_z1_1=0.6157645285,
            p_z2_1=0.4164692396,
            p_x1_given_z1=np.array([0.2908947929, 0.1307888401], dtype=float),
            p_x3_given_cz2=np.array(
                [
                    [0.4491857282, 0.7561593030],
                    [0.4489857282, 0.7559593030],
                    [0.4490531731, 0.7560267479],
                ],
                dtype=float,
            ),
            p_x2_given_x3=np.array([0.7817061637, 0.7171767286], dtype=float),
            p_y1_given_cz1z2x1x2=np.array([[[[[0.417982044790462, 0.7741774041584703], [0.3396075462031065, 0.3324127051858578]], [[0.9469748814089217, 0.6456323221093452], [0.9061055046297257, 0.933135343519298]]], [[[0.2136208139300165, 0.7197981476065355], [0.9397360804845243, 0.5269225046809068]], [[0.08521682662606503, 0.05965349853077932], [0.9060733102494665, 0.9151407757059121]]]], [[[[0.8714887153526467, 0.4826733676346568], [0.5149545581133746, 0.7575739854691977]], [[0.22149248902455446, 0.7773378582528554], [0.2701566236849354, 0.13292465260448272]]], [[[0.06412576364035459, 0.8845954665884618], [0.24438649631776022, 0.18634971712778206]], [[0.021726313236049285, 0.4380160919797669], [0.1449861845764206, 0.28097925985718014]]]], [[[[0.6330193133873279, 0.5067490534866553], [0.46677062047397544, 0.6859387811342678]], [[0.6831948379153381, 0.6389430383147142], [0.004389065980495473, 0.13780179834638837]]], [[[0.8870434444628734, 0.0782315270903048], [0.4040101012244573, 0.016627311219515193]], [[0.6204568574885103, 0.7860227375379367], [0.8512015642271993, 0.3299179850642367]]]]], dtype=float),
        )

    @classmethod
    def random(cls, seed: int) -> "Task3SCM":
        rng = np.random.default_rng(seed)
        return cls(
            p_context=rng.dirichlet(np.ones(N_CONTEXTS)),
            p_z1_1=float(rng.beta(1.0,1.0)),
            p_z2_1=float(rng.beta(1.0,1.0)),
            p_x1_given_z1=rng.beta(1.0,1.0,size=2),
            p_x3_given_cz2=rng.beta(1.0,1.0,size=(N_CONTEXTS, 2)),
            p_x2_given_x3=rng.beta(1.0,1.0,size=2),
            p_y1_given_cz1z2x1x2=rng.beta(1.0,1.0,size=(N_CONTEXTS,2,2,2,2)),
        )

    def arm_means(self, context: int) -> np.ndarray:
        pz1 = np.array([1.0-self.p_z1_1, self.p_z1_1], dtype=float)
        pz2 = np.array([1.0-self.p_z2_1, self.p_z2_1], dtype=float)
        out = np.zeros(K, dtype=float)
        for action,(fix_x1,fix_x2) in enumerate(ACTIONS):
            mu = 0.0
            for z1 in (0,1):
                for z2 in (0,1):
                    if fix_x1 is None:
                        q1=self.p_x1_given_z1[z1]
                        x1_values=((0,1.0-q1),(1,q1))
                    else:
                        x1_values=((fix_x1,1.0),)
                    if fix_x2 is None:
                        q3=self.p_x3_given_cz2[context, z2]
                        x3_values=((0,1.0-q3),(1,q3))
                    else:
                        x3_values=((0,1.0),)
                    for x1,wx1 in x1_values:
                        if fix_x2 is None:
                            for x3,wx3 in x3_values:
                                q2=self.p_x2_given_x3[x3]
                                for x2,wx2 in ((0,1.0-q2),(1,q2)):
                                    mu += (
                                        pz1[z1]*pz2[z2]*wx1*wx3*wx2
                                        * self.p_y1_given_cz1z2x1x2[context,z1,z2,x1,x2]
                                    )
                        else:
                            mu += (
                                pz1[z1]*pz2[z2]*wx1
                                * self.p_y1_given_cz1z2x1x2[context,z1,z2,x1,fix_x2]
                            )
            out[action]=mu
        return out

    def sample_context(self, rng: np.random.Generator) -> int:
        return int(rng.choice(N_CONTEXTS, p=self.p_context))

    def sample(
        self,
        action: int,
        context: int,
        rng: np.random.Generator,
    ) -> Tuple[int, int, int, int, int, int, int]:
        fix_x1,fix_x2=ACTIONS[action]
        z1=int(rng.random()<self.p_z1_1)
        z2=int(rng.random()<self.p_z2_1)
        if fix_x1 is None:
            x1=int(rng.random()<self.p_x1_given_z1[z1])
        else:
            x1=fix_x1
        x3=int(rng.random()<self.p_x3_given_cz2[context, z2])
        if fix_x2 is None:
            x2=int(rng.random()<self.p_x2_given_x3[x3])
        else:
            x2=fix_x2
        y=int(rng.random()<self.p_y1_given_cz1z2x1x2[context,z1,z2,x1,x2])
        return context,z1,z2,x1,x3,x2,y


# Shared-CPT posterior used by the causal methods

class CPTPosterior:
    """Independent Beta posteriors for the Bernoulli CPT rows."""

    def __init__(self, prior: float = 1.0) -> None:
        self.c_counts = np.full(N_CONTEXTS, prior, dtype=float)

        self.z1_alpha = prior
        self.z1_beta = prior
        self.z2_alpha = prior
        self.z2_beta = prior

        self.x1_alpha = np.full(2, prior, dtype=float)
        self.x1_beta = np.full(2, prior, dtype=float)

        self.x3_alpha = np.full((N_CONTEXTS, 2), prior, dtype=float)
        self.x3_beta = np.full((N_CONTEXTS, 2), prior, dtype=float)

        self.x2_alpha = np.full(2, prior, dtype=float)
        self.x2_beta = np.full(2, prior, dtype=float)

        self.y_alpha = np.full(
            (N_CONTEXTS, 2, 2, 2, 2),
            prior,
            dtype=float,
        )
        self.y_beta = np.full(
            (N_CONTEXTS, 2, 2, 2, 2),
            prior,
            dtype=float,
        )

    def observe_context(self, c: int) -> None:
        """Update the root-context CPT when C is observed before the action."""
        self.c_counts[c] += 1.0

    def update_after_action(
        self,
        action: int,
        c: int,
        z1: int,
        z2: int,
        x1: int,
        x3: int,
        x2: int,
        y: int,
    ) -> None:
        """Update exactly the non-intervened post-action mechanisms."""
        if z1 == 1:
            self.z1_alpha += 1.0
        else:
            self.z1_beta += 1.0

        if z2 == 1:
            self.z2_alpha += 1.0
        else:
            self.z2_beta += 1.0

        fix_x1, fix_x2 = ACTIONS[action]

        if fix_x1 is None:
            if x1 == 1:
                self.x1_alpha[z1] += 1.0
            else:
                self.x1_beta[z1] += 1.0

        if x3 == 1:
            self.x3_alpha[c, z2] += 1.0
        else:
            self.x3_beta[c, z2] += 1.0

        if fix_x2 is None:
            if x2 == 1:
                self.x2_alpha[x3] += 1.0
            else:
                self.x2_beta[x3] += 1.0

        idx = (
            c,
            z1,
            z2,
            x1,
            x2,
        )

        if y == 1:
            self.y_alpha[idx] += 1.0
        else:
            self.y_beta[idx] += 1.0

    def sample_arm_means(
        self,
        rng: np.random.Generator,
        n: int,
        context: int,
    ) -> np.ndarray:
        """Draw n shared-CPT posterior samples and return all nine arm means."""
        pz1_1 = rng.beta(
            self.z1_alpha,
            self.z1_beta,
            size=n,
        )
        pz2_1 = rng.beta(
            self.z2_alpha,
            self.z2_beta,
            size=n,
        )

        px1_1 = np.empty(
            (n, 2),
            dtype=float,
        )
        px3_1 = np.empty(
            (n, 2),
            dtype=float,
        )
        px2_1 = np.empty(
            (n, 2),
            dtype=float,
        )

        for z1 in (0, 1):
            px1_1[:, z1] = rng.beta(
                self.x1_alpha[z1],
                self.x1_beta[z1],
                size=n,
            )

        for z2 in (0, 1):
            px3_1[:, z2] = rng.beta(
                self.x3_alpha[context, z2],
                self.x3_beta[context, z2],
                size=n,
            )

        for x3 in (0, 1):
            px2_1[:, x3] = rng.beta(
                self.x2_alpha[x3],
                self.x2_beta[x3],
                size=n,
            )

        py1 = np.empty(
            (n, 2, 2, 2, 2),
            dtype=float,
        )

        for z1 in (0, 1):
            for z2 in (0, 1):
                for x1 in (0, 1):
                    for x2 in (0, 1):
                        py1[:, z1, z2, x1, x2] = rng.beta(
                            self.y_alpha[
                                context,
                                z1,
                                z2,
                                x1,
                                x2,
                            ],
                            self.y_beta[
                                context,
                                z1,
                                z2,
                                x1,
                                x2,
                            ],
                            size=n,
                        )

        out = np.zeros(
            (n, K),
            dtype=float,
        )

        pz1 = (
            1.0 - pz1_1,
            pz1_1,
        )
        pz2 = (
            1.0 - pz2_1,
            pz2_1,
        )

        ones = np.ones(
            n,
            dtype=float,
        )

        for action, (fix_x1, fix_x2) in enumerate(ACTIONS):
            mu = np.zeros(
                n,
                dtype=float,
            )

            for z1 in (0, 1):
                for z2 in (0, 1):
                    if fix_x1 is None:
                        q1 = px1_1[:, z1]
                        x1_values = (
                            (0, 1.0 - q1),
                            (1, q1),
                        )
                    else:
                        x1_values = (
                            (fix_x1, ones),
                        )

                    for x1, wx1 in x1_values:
                        if fix_x2 is None:
                            q3 = px3_1[:, z2]

                            for x3, wx3 in (
                                (0, 1.0 - q3),
                                (1, q3),
                            ):
                                q2 = px2_1[:, x3]

                                for x2, wx2 in (
                                    (0, 1.0 - q2),
                                    (1, q2),
                                ):
                                    mu += (
                                        pz1[z1]
                                        * pz2[z2]
                                        * wx1
                                        * wx3
                                        * wx2
                                        * py1[
                                            :,
                                            z1,
                                            z2,
                                            x1,
                                            x2,
                                        ]
                                    )
                        else:
                            mu += (
                                pz1[z1]
                                * pz2[z2]
                                * wx1
                                * py1[
                                    :,
                                    z1,
                                    z2,
                                    x1,
                                    fix_x2,
                                ]
                            )

            out[:, action] = mu

        return out


# Helpers

def _argmax_random_tie(
    values: np.ndarray,
    rng: np.random.Generator,
) -> int:
    maximum = np.max(values)

    idx = np.flatnonzero(
        np.isclose(
            values,
            maximum,
            rtol=0.0,
            atol=1e-14,
        )
    )

    return int(
        rng.choice(idx)
    )


def _record_regret(
    cumulative: float,
    action: int,
    true_means: np.ndarray,
) -> float:
    return cumulative + float(
        np.max(true_means)
        - true_means[action]
    )


def _print_progress(
    name: str,
    trial: int,
    trials: int,
) -> None:
    if trials >= 20 and (
        (trial + 1)
        % max(1, trials // 10)
        == 0
        or trial + 1 == trials
    ):
        print(
            f"[{name}] {trial + 1}/{trials} trials"
        )


# Baseline 1: contextual UCB

def run_ucb(
    scm: Task3SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    true_means = np.stack(
        [scm.arm_means(c) for c in range(N_CONTEXTS)]
    )

    out = np.zeros(
        (trials, horizon),
        dtype=float,
    )

    for trial in range(trials):
        rng = np.random.default_rng(
            seed + trial
        )

        pulls = np.zeros(
            (N_CONTEXTS, K),
            dtype=int,
        )
        reward_sum = np.zeros(
            (N_CONTEXTS, K),
            dtype=float,
        )

        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(rng)

            untried = np.flatnonzero(
                pulls[c] == 0
            )

            if len(untried) > 0:
                action = int(
                    untried[0]
                )
            else:
                empirical = (
                    reward_sum[c]
                    / pulls[c]
                )
                bonus = np.sqrt(
                    2.0
                    * np.log(t + 2.0)
                    / pulls[c]
                )

                action = _argmax_random_tie(
                    empirical + bonus,
                    rng,
                )

            (
                _,
                z1,
                z2,
                x1,
                x3,
                x2,
                y,
            ) = scm.sample(
                action,
                c,
                rng,
            )

            pulls[c, action] += 1
            reward_sum[c, action] += y

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )

            out[trial, t] = cumulative_regret

        _print_progress(
            "UCB",
            trial,
            trials,
        )

    return out


# Baseline 2: context-specific Bernoulli Thompson Sampling

def run_bernoulli_ts(
    scm: Task3SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    true_means = np.stack(
        [scm.arm_means(c) for c in range(N_CONTEXTS)]
    )

    out = np.zeros(
        (trials, horizon),
        dtype=float,
    )

    for trial in range(trials):
        rng = np.random.default_rng(
            seed + trial
        )

        alpha = np.ones(
            (N_CONTEXTS, K),
            dtype=float,
        )
        beta = np.ones(
            (N_CONTEXTS, K),
            dtype=float,
        )

        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(rng)

            theta = rng.beta(
                alpha[c],
                beta[c],
            )

            action = _argmax_random_tie(
                theta,
                rng,
            )

            (
                _,
                z1,
                z2,
                x1,
                x3,
                x2,
                y,
            ) = scm.sample(
                action,
                c,
                rng,
            )

            alpha[c, action] += y
            beta[c, action] += 1 - y

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )

            out[trial, t] = cumulative_regret

        _print_progress(
            "Bernoulli TS",
            trial,
            trials,
        )

    return out


# Baseline 3: causal inverse-variance TS inspired by Lee & Bareinboim (2019)

def _beta_from_mean_variance(
    mean: float,
    var: float,
) -> Tuple[float, float]:
    """Moment-match a Beta distribution with numerical safety clipping."""
    eps = 1e-8
    m = float(np.clip(mean, eps, 1.0 - eps))
    vmax = m * (1.0 - m)
    v = float(np.clip(var, eps, vmax * (1.0 - 1e-8)))

    concentration = m * (1.0 - m) / v - 1.0
    concentration = max(concentration, 2.0)

    return (
        m * concentration,
        (1.0 - m) * concentration,
    )


def run_causal_inverse_variance_ts(
    scm: Task3SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    """
    Causal inverse-variance Thompson-sampling comparator inspired by
    Lee and Bareinboim (2019). It combines a direct context-action
    Bernoulli estimate with an auxiliary shared-CPT causal estimate using
    inverse-variance weighting, followed by Beta moment matching.
    It is not an exact implementation of the full z^2-ID/bMVWA procedure.
    """
    baseline_cpt_samples = 50

    true_means = np.stack(
        [scm.arm_means(c) for c in range(N_CONTEXTS)]
    )

    out = np.zeros(
        (trials, horizon),
        dtype=float,
    )

    for trial in range(trials):
        rng = np.random.default_rng(
            seed + trial
        )

        direct_alpha = np.ones(
            (N_CONTEXTS, K),
            dtype=float,
        )
        direct_beta = np.ones(
            (N_CONTEXTS, K),
            dtype=float,
        )

        causal = CPTPosterior(
            prior=0.5
        )

        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(
                rng
            )
            causal.observe_context(c)

            causal_draws = causal.sample_arm_means(
                rng,
                baseline_cpt_samples,
                c,
            )

            causal_mean = np.mean(
                causal_draws,
                axis=0,
            )
            causal_var = np.var(
                causal_draws,
                axis=0,
                ddof=1,
            )

            theta = np.empty(
                K,
                dtype=float,
            )

            for action in range(K):
                alpha = direct_alpha[
                    c,
                    action,
                ]
                beta = direct_beta[
                    c,
                    action,
                ]

                direct_mean = (
                    alpha
                    / (alpha + beta)
                )

                direct_var = (
                    direct_mean
                    * (1.0 - direct_mean)
                    / (alpha + beta + 1.0)
                )

                v_direct = max(
                    float(direct_var),
                    1e-10,
                )
                v_causal = max(
                    float(causal_var[action]),
                    1e-10,
                )

                combined_mean = (
                    direct_mean / v_direct
                    + causal_mean[action] / v_causal
                ) / (
                    1.0 / v_direct
                    + 1.0 / v_causal
                )

                combined_var = 1.0 / (
                    1.0 / v_direct
                    + 1.0 / v_causal
                )

                alpha_hat, beta_hat = (
                    _beta_from_mean_variance(
                        float(combined_mean),
                        float(combined_var),
                    )
                )

                theta[action] = rng.beta(
                    alpha_hat,
                    beta_hat,
                )

            action = _argmax_random_tie(
                theta,
                rng,
            )

            (
                _,
                z1,
                z2,
                x1,
                x3,
                x2,
                y,
            ) = scm.sample(
                action,
                c,
                rng,
            )

            direct_alpha[
                c,
                action,
            ] += y

            direct_beta[
                c,
                action,
            ] += 1 - y

            causal.update_after_action(
                action,
                c,
                z1,
                z2,
                x1,
                x3,
                x2,
                y,
            )

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )

            out[
                trial,
                t,
            ] = cumulative_regret

        _print_progress(
            "Causal inverse-variance TS",
            trial,
            trials,
        )

    return out


# Proposed causal Thompson Sampling

def run_causal_ts(
    scm: Task3SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    true_means = np.stack(
        [scm.arm_means(c) for c in range(N_CONTEXTS)]
    )

    out = np.zeros(
        (trials, horizon),
        dtype=float,
    )

    for trial in range(trials):
        rng = np.random.default_rng(
            seed + trial
        )

        posterior = CPTPosterior()
        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(
                rng
            )
            posterior.observe_context(c)

            sampled_means = (
                posterior.sample_arm_means(
                    rng,
                    1,
                    c,
                )[0]
            )

            action = _argmax_random_tie(
                sampled_means,
                rng,
            )

            (
                _,
                z1,
                z2,
                x1,
                x3,
                x2,
                y,
            ) = scm.sample(
                action,
                c,
                rng,
            )

            posterior.update_after_action(
                action,
                c,
                z1,
                z2,
                x1,
                x3,
                x2,
                y,
            )

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )

            out[trial, t] = cumulative_regret

        _print_progress(
            "Causal TS",
            trial,
            trials,
        )

    return out


# IDS

def _mc_delta_and_information(
    mu_samples: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Monte Carlo plug-in estimates of expected regret and reward-only
    information gain I(A*;Y_a).
    """
    n, k = mu_samples.shape

    a_star = np.argmax(
        mu_samples,
        axis=1,
    )

    best_mu = mu_samples[
        np.arange(n),
        a_star,
    ]

    delta = np.mean(
        best_mu[:, None]
        - mu_samples,
        axis=0,
    )

    delta = np.clip(
        delta,
        0.0,
        1.0,
    )

    p_star = (
        np.bincount(
            a_star,
            minlength=k,
        ).astype(float)
        / n
    )

    info = np.zeros(
        k,
        dtype=float,
    )

    for action in range(k):
        mu_a = mu_samples[
            :,
            action,
        ]

        joint_y1 = (
            np.bincount(
                a_star,
                weights=mu_a,
                minlength=k,
            ).astype(float)
            / n
        )

        joint_y0 = (
            p_star
            - joint_y1
        )

        p_y1 = float(
            np.sum(
                joint_y1
            )
        )
        p_y0 = 1.0 - p_y1

        g = 0.0

        for j in range(k):
            if p_star[j] <= 0.0:
                continue

            q1 = joint_y1[j]

            if (
                q1 > 0.0
                and p_y1 > 0.0
            ):
                g += (
                    q1
                    * math.log(
                        q1
                        / (
                            p_star[j]
                            * p_y1
                        )
                    )
                )

            q0 = joint_y0[j]

            if (
                q0 > 0.0
                and p_y0 > 0.0
            ):
                g += (
                    q0
                    * math.log(
                        q0
                        / (
                            p_star[j]
                            * p_y0
                        )
                    )
                )

        info[action] = max(
            g,
            0.0,
        )

    return (
        delta,
        np.clip(
            info,
            0.0,
            math.log(2.0),
        ),
    )


def _ids_ratio(
    regret: float,
    info: float,
) -> float:
    if regret <= 1e-15:
        return 0.0

    if info <= 1e-15:
        return math.inf

    return regret * regret / info


def _ids_distribution(
    delta: np.ndarray,
    info: np.ndarray,
) -> np.ndarray:
    """Exact finite-action IDS search over all one- and two-action supports."""
    k = len(delta)

    best_ratio = math.inf
    best = None

    for i in range(k):
        ratio = _ids_ratio(
            float(delta[i]),
            float(info[i]),
        )

        if ratio < best_ratio:
            best_ratio = ratio
            best = (
                i,
                i,
                1.0,
            )

        for j in range(
            i + 1,
            k,
        ):
            a = float(
                delta[i]
                - delta[j]
            )
            b = float(
                delta[j]
            )
            c = float(
                info[i]
                - info[j]
            )
            d = float(
                info[j]
            )

            candidates = [
                0.0,
                1.0,
            ]

            if abs(a * c) > 1e-15:
                lam = (
                    c * b
                    - 2.0 * a * d
                ) / (a * c)

                if 0.0 < lam < 1.0:
                    candidates.append(
                        lam
                    )

            if abs(a) > 1e-15:
                lam0 = -b / a

                if 0.0 < lam0 < 1.0:
                    candidates.append(
                        lam0
                    )

            for lam in candidates:
                expected_regret = (
                    lam * delta[i]
                    + (1.0 - lam)
                    * delta[j]
                )
                expected_info = (
                    lam * info[i]
                    + (1.0 - lam)
                    * info[j]
                )

                ratio = _ids_ratio(
                    float(
                        expected_regret
                    ),
                    float(
                        expected_info
                    ),
                )

                if ratio < best_ratio:
                    best_ratio = ratio
                    best = (
                        i,
                        j,
                        float(lam),
                    )

    if (
        best is None
        or not np.isfinite(
            best_ratio
        )
    ):
        p = np.zeros(
            k,
            dtype=float,
        )
        p[
            int(
                np.argmin(
                    delta
                )
            )
        ] = 1.0
        return p

    i, j, lam = best

    p = np.zeros(
        k,
        dtype=float,
    )

    p[i] += lam
    p[j] += 1.0 - lam

    return p / p.sum()


def run_ids(
    scm: Task3SCM,
    trials: int,
    horizon: int,
    seed: int,
    posterior_samples: int,
) -> np.ndarray:
    true_means = np.stack(
        [scm.arm_means(c) for c in range(N_CONTEXTS)]
    )

    out = np.zeros(
        (trials, horizon),
        dtype=float,
    )

    for trial in range(trials):
        rng = np.random.default_rng(
            seed + trial
        )

        posterior = CPTPosterior()
        cumulative_regret = 0.0

        for t in range(horizon):
            c = scm.sample_context(
                rng
            )
            posterior.observe_context(c)

            mu_samples = (
                posterior.sample_arm_means(
                    rng,
                    posterior_samples,
                    c,
                )
            )

            (
                delta_hat,
                info_hat,
            ) = (
                _mc_delta_and_information(
                    mu_samples
                )
            )

            pi = _ids_distribution(
                delta_hat,
                info_hat,
            )

            action = int(
                rng.choice(
                    K,
                    p=pi,
                )
            )

            (
                _,
                z1,
                z2,
                x1,
                x3,
                x2,
                y,
            ) = scm.sample(
                action,
                c,
                rng,
            )

            posterior.update_after_action(
                action,
                c,
                z1,
                z2,
                x1,
                x3,
                x2,
                y,
            )

            cumulative_regret = _record_regret(
                cumulative_regret,
                action,
                true_means[c],
            )

            out[trial, t] = cumulative_regret

        _print_progress(
            "IDS",
            trial,
            trials,
        )

    return out


# Plotting: pointwise 95% confidence intervals for the mean

def _plot_curve(
    ax,
    data: np.ndarray,
    label: str,
    color: str,
    marker: str,
    horizon: int,
) -> None:
    mean = np.mean(data, axis=0)
    sd = np.std(data, axis=0, ddof=1)
    se = sd / np.sqrt(data.shape[0])

    x = np.arange(1, horizon + 1)
    lower = np.maximum(0.0, mean - 1.96 * se)
    upper = mean + 1.96 * se

    mark_every = max(1, horizon // 10)

    ax.plot(
        x,
        mean,
        label=label,
        color=color,
        marker=marker,
        markevery=mark_every,
        markersize=6.5,
        linewidth=2.0,
        markeredgewidth=1.2,
        markerfacecolor="none" if marker != "*" else color,
    )

    ax.fill_between(
        x,
        lower,
        upper,
        color=color,
        alpha=0.16,
        linewidth=0,
    )


def make_figure(
    results: dict,
    horizon: int,
) -> None:
    export_dpi = 600
    fig_width = 3200 / export_dpi
    fig_height = 2500 / export_dpi

    fig, ax = plt.subplots(
        figsize=(fig_width, fig_height),
        dpi=export_dpi,
    )

    _plot_curve(
        ax,
        results["ucb"],
        "UCB on POMISs",
        "#B33F40",
        "^",
        horizon,
    )

    _plot_curve(
        ax,
        results["ts"],
        "Bernoulli TS on POMISs",
        "#0177B3",
        "s",
        horizon,
    )

    _plot_curve(
        ax,
        results["causal_baseline"],
        "Causal inverse-variance TS",
        "#0000CC",
        "*",
        horizon,
    )

    _plot_curve(
        ax,
        results["causal_ts"],
        "TS for Causal Bandits with Non-manipulable Variables",
        "#48A14D",
        "o",
        horizon,
    )

    _plot_curve(
        ax,
        results["ids"],
        "IDS for Causal Bandits with Non-manipulable Variables",
        "#D100D1",
        "D",
        horizon,
    )

    ax.set_xlim(0, horizon)
    ax.set_ylim(bottom=0)

    ax.set_xlabel(
        "Time",
        fontsize=12.5,
    )
    ax.set_ylabel(
        "Mean Cumulative Regret",
        fontsize=12.5,
    )

    ax.tick_params(
        axis="both",
        which="major",
        labelsize=10.5,
        width=1.0,
        length=4.0,
    )

    for spine in ax.spines.values():
        spine.set_linewidth(1.0)

    ax.grid(
        True,
        alpha=0.28,
        linewidth=0.7,
    )

    ax.legend(
        fontsize=8.0,
        loc="upper left",
        frameon=True,
        framealpha=0.95,
        borderpad=0.6,
        labelspacing=0.45,
        handlelength=2.2,
        handletextpad=0.6,
    )

    fig.subplots_adjust(
        left=0.145,
        right=0.985,
        bottom=0.155,
        top=0.975,
    )

    output_file = "task3_fig3c.png"

    fig.savefig(
        output_file,
        dpi=export_dpi,
        facecolor="white",
        edgecolor="none",
    )

    print(
        f"Saved publication figure to: "
        f"{output_file} (3200 x 2500 px, 600 dpi)"
    )

    plt.show()


# Experiment settings

TRIALS = 500
HORIZON = 5000

IDS_SAMPLES = 1000


def main() -> None:
    if TRIALS < 2:
        raise ValueError(
            "Use at least 2 trials so the confidence interval is defined."
        )

    if HORIZON < 1:
        raise ValueError(
            "HORIZON must be positive."
        )

    if IDS_SAMPLES < 1:
        raise ValueError(
            "IDS_SAMPLES must be positive."
        )


    scm = Task3SCM.fixed()

    true_means = np.stack(
        [scm.arm_means(c) for c in range(N_CONTEXTS)]
    )

    print(
        "Task 3: Z1 -> X1 -> Y, Z1 -> Y, "
        "Z2 -> X3 -> X2 -> Y, Z2 -> Y, C -> Y; "
        "Z1 and Z2 are non-manipulable and C is context"
    )

    print(
        "SCM: fixed structured SCM shared by all methods and trials"
    )
    print(
        f"Trials: {TRIALS}, horizon: {HORIZON}"
    )
    print(
        f"IDS posterior samples per round: {IDS_SAMPLES}"
    )

    print(
        f"P(C) = {scm.p_context}"
    )
    print(
        f"P(Z1=1) = {scm.p_z1_1:.8f}"
    )
    print(
        f"P(Z2=1) = {scm.p_z2_1:.8f}"
    )

    print(
        "P(X3=1 | C,Z2), indexed [C,Z2]:"
    )
    print(
        scm.p_x3_given_cz2
    )

    for c in range(N_CONTEXTS):
        print(
            f"\nTrue action means for C={c}:"
        )

        for name, mu in zip(
            ACTION_NAMES,
            true_means[c],
        ):
            print(
                f"  {name:17s}: {mu:.8f}"
            )

        optimal = int(
            np.argmax(
                true_means[c]
            )
        )

        print(
            f"Optimal arm for C={c}: "
            f"{ACTION_NAMES[optimal]}"
        )

    print()

    results = {
        "ucb": run_ucb(
            scm,
            TRIALS,
            HORIZON,
            seed=1_000_000,
        ),
        "ts": run_bernoulli_ts(
            scm,
            TRIALS,
            HORIZON,
            seed=2_000_000,
        ),
        "causal_baseline": run_causal_inverse_variance_ts(
                scm,
                TRIALS,
                HORIZON,
                seed=3_000_000,
            ),
        "causal_ts": run_causal_ts(
                scm,
                TRIALS,
                HORIZON,
                seed=4_000_000,
            ),
        "ids": run_ids(
            scm,
            TRIALS,
            HORIZON,
            seed=5_000_000,
            posterior_samples=IDS_SAMPLES,
        ),
    }

    make_figure(
        results,
        HORIZON,
    )




if __name__ == "__main__":
    main()
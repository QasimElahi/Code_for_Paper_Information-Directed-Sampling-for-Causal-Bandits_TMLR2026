"""Task 1 experiment for Fig. 3(a).

Causal graph:
    Z -> X -> Y
    Z -> Y

Z is non-manipulable.

POMIS-induced actions:
    do(), do(X=0), do(X=1)

Methods:
    1. UCB1 on the POMIS arms.
    2. Bernoulli Thompson Sampling on the POMIS arms.
    3. Causal inverse-variance Thompson-sampling baseline inspired by
       Lee & Bareinboim (2019).
    4. Proposed causal Thompson Sampling using the shared-CPT posterior.
    5. Proposed IDS using Monte Carlo estimates from the shared-CPT posterior.

Implementation separation:
    - The causal inverse-variance baseline combines a direct arm estimate with
      an auxiliary causal estimate obtained from a shared-CPT posterior. It is
      inspired by Lee & Bareinboim (2019), but is not claimed to be an exact
      implementation of their full z^2-ID/bMVWA procedure.
    - Proposed causal TS uses one shared-CPT posterior draw per round.
    - Proposed IDS uses Monte Carlo samples from its own shared-CPT posterior
      to estimate expected regret and reward information gain.


Dependencies: numpy, matplotlib.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple

import numpy as np

import matplotlib.pyplot as plt




OBS = 0
DO_X0 = 1
DO_X1 = 2
K = 3
ACTION_NAMES = ("do()", "do(X=0)", "do(X=1)")


@dataclass(frozen=True)
class Task1SCM:
    """Binary SCM for Z -> X -> Y and Z -> Y."""

    p_z1: float                 # P(Z=1)
    p_x1_given_z: np.ndarray   # shape (2,), P(X=1 | Z=z)
    p_y1_given_xz: np.ndarray  # shape (2,2), P(Y=1 | X=x,Z=z)

    @classmethod
    def fixed(cls) -> "Task1SCM":
        """Fixed Task-1 SCM used by every method and trial."""
        return cls(
            p_z1=0.12356373351670792,
            p_x1_given_z=np.array(
                [np.float64(0.18958475566051883), np.float64(0.5065343148508826)],
                dtype=float,
            ),
            p_y1_given_xz=np.array(
                [
                    [np.float64(0.4397208961670168), np.float64(0.18266739621607925)],
                    [np.float64(0.5313639348316782), np.float64(0.6778901276752644)],
                ],
                dtype=float,
            ),
        )

    def arm_means(self) -> np.ndarray:
        """Return [mu_do(), mu_do(X=0), mu_do(X=1)] exactly."""
        pz = np.array([1.0 - self.p_z1, self.p_z1])

        mu_x0 = float(np.sum(pz * self.p_y1_given_xz[0, :]))
        mu_x1 = float(np.sum(pz * self.p_y1_given_xz[1, :]))

        mu_obs = 0.0
        for z in (0, 1):
            px1 = self.p_x1_given_z[z]
            mu_obs += pz[z] * (
                (1.0 - px1) * self.p_y1_given_xz[0, z]
                + px1 * self.p_y1_given_xz[1, z]
            )

        return np.array([mu_obs, mu_x0, mu_x1], dtype=float)

    def sample(self, action: int, rng: np.random.Generator) -> Tuple[int, int, int]:
        """Generate one complete observed sample (Z,X,Y) under an action."""
        z = int(rng.random() < self.p_z1)

        if action == OBS:
            x = int(rng.random() < self.p_x1_given_z[z])
        elif action == DO_X0:
            x = 0
        elif action == DO_X1:
            x = 1
        else:
            raise ValueError(f"Unknown action index {action}")

        y = int(rng.random() < self.p_y1_given_xz[x, z])
        return z, x, y




class CPTPosterior:
    """
    Independent Beta(1,1) priors for each Bernoulli CPT row.

    Counts are updated only for non-intervened variables, exactly as required by
    the truncated-factorization likelihood:
      - Z is never intervened on -> always update P(Z).
      - X is updated only under do().
      - Y is never intervened on -> always update P(Y|X,Z).
    """

    def __init__(self, prior: float = 1.0) -> None:
        self.z_alpha = float(prior)
        self.z_beta = float(prior)

        self.x_alpha = np.full(2, prior, dtype=float)
        self.x_beta = np.full(2, prior, dtype=float)

        self.y_alpha = np.full((2, 2), prior, dtype=float)
        self.y_beta = np.full((2, 2), prior, dtype=float)

    def update(self, action: int, z: int, x: int, y: int) -> None:
        if z == 1:
            self.z_alpha += 1.0
        else:
            self.z_beta += 1.0

        if action == OBS:
            if x == 1:
                self.x_alpha[z] += 1.0
            else:
                self.x_beta[z] += 1.0

        if y == 1:
            self.y_alpha[x, z] += 1.0
        else:
            self.y_beta[x, z] += 1.0

    def sample_arm_means(self, rng: np.random.Generator, n: int) -> np.ndarray:
        """
        Draw n posterior CPT samples and return their three action means.

        Output shape: (n,3), columns ordered as do(), do(X=0), do(X=1).
        """
        pz1 = rng.beta(self.z_alpha, self.z_beta, size=n)

        px1 = np.empty((n, 2), dtype=float)
        for z in (0, 1):
            px1[:, z] = rng.beta(self.x_alpha[z], self.x_beta[z], size=n)

        py1 = np.empty((n, 2, 2), dtype=float)
        for x in (0, 1):
            for z in (0, 1):
                py1[:, x, z] = rng.beta(
                    self.y_alpha[x, z], self.y_beta[x, z], size=n
                )

        pz0 = 1.0 - pz1

        mu_x0 = pz0 * py1[:, 0, 0] + pz1 * py1[:, 0, 1]
        mu_x1 = pz0 * py1[:, 1, 0] + pz1 * py1[:, 1, 1]

        mu_obs = (
            pz0
            * ((1.0 - px1[:, 0]) * py1[:, 0, 0] + px1[:, 0] * py1[:, 1, 0])
            + pz1
            * ((1.0 - px1[:, 1]) * py1[:, 0, 1] + px1[:, 1] * py1[:, 1, 1])
        )

        return np.column_stack((mu_obs, mu_x0, mu_x1))




def _argmax_random_tie(values: np.ndarray, rng: np.random.Generator) -> int:
    m = np.max(values)
    idx = np.flatnonzero(np.isclose(values, m, rtol=0.0, atol=1e-14))
    return int(rng.choice(idx))


def _record_regret(cum: float, action: int, true_means: np.ndarray) -> float:
    return cum + float(np.max(true_means) - true_means[action])


def _print_progress(name: str, r: int, trials: int) -> None:
    if trials >= 20 and ((r + 1) % max(1, trials // 10) == 0 or r + 1 == trials):
        print(f"[{name}] {r + 1}/{trials} trials")




def run_ucb(
    scm: Task1SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    means = scm.arm_means()
    out = np.zeros((trials, horizon), dtype=float)

    for r in range(trials):
        rng = np.random.default_rng(seed + r)
        pulls = np.zeros(K, dtype=int)
        reward_sum = np.zeros(K, dtype=float)
        cum_regret = 0.0

        for t in range(horizon):
            if t < K:
                action = t
            else:
                empirical = reward_sum / pulls
                bonus = np.sqrt(2.0 * np.log(t + 1.0) / pulls)
                action = _argmax_random_tie(empirical + bonus, rng)

            _, _, y = scm.sample(action, rng)
            pulls[action] += 1
            reward_sum[action] += y

            cum_regret = _record_regret(cum_regret, action, means)
            out[r, t] = cum_regret

        _print_progress("UCB", r, trials)

    return out




def run_bernoulli_ts(
    scm: Task1SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    means = scm.arm_means()
    out = np.zeros((trials, horizon), dtype=float)

    for r in range(trials):
        rng = np.random.default_rng(seed + r)
        alpha = np.ones(K, dtype=float)
        beta = np.ones(K, dtype=float)
        cum_regret = 0.0

        for t in range(horizon):
            theta = rng.beta(alpha, beta)
            action = _argmax_random_tie(theta, rng)
            _, _, y = scm.sample(action, rng)

            alpha[action] += y
            beta[action] += 1 - y

            cum_regret = _record_regret(cum_regret, action, means)
            out[r, t] = cum_regret

        _print_progress("Bernoulli TS", r, trials)

    return out




def _beta_from_mean_variance(
    mean: float,
    var: float,
) -> Tuple[float, float]:
    """Moment-match a Beta distribution with numerical safety clipping."""
    eps = 1e-8
    m = float(np.clip(mean, eps, 1.0 - eps))
    vmax = m * (1.0 - m)
    v = float(np.clip(var, eps, vmax * (1.0 - 1e-8)))

    concentration = m * (1.0 - m) / v - 1.0
    concentration = max(concentration, 2.0)

    return (
        m * concentration,
        (1.0 - m) * concentration,
    )


def run_causal_inverse_variance_ts(
    scm: Task1SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    """
    Causal inverse-variance Thompson-sampling comparator.

    For each intervention, combine:
      (i) a direct arm-specific Bernoulli estimate, and
      (ii) a causal estimate computed from a shared-CPT posterior.

    The two estimates are combined by inverse-variance weighting. Because the
    direct and causal estimates can depend on overlapping observations, this is
    deliberately described as a causal inverse-variance baseline inspired by
    Lee & Bareinboim (2019), not as an exact implementation of their full
    covariance-aware z^2-ID/bMVWA procedure.

    """
    baseline_cpt_samples = 50

    means = scm.arm_means()
    out = np.zeros((trials, horizon), dtype=float)

    for r in range(trials):
        rng = np.random.default_rng(seed + r)

        alpha = np.ones(K, dtype=float)
        beta = np.ones(K, dtype=float)

        causal = CPTPosterior(prior=0.5)

        cum_regret = 0.0

        for t in range(horizon):
            causal_draws = causal.sample_arm_means(
                rng,
                n=baseline_cpt_samples,
            )
            causal_mean = causal_draws.mean(axis=0)
            causal_var = causal_draws.var(axis=0, ddof=1)

            theta = np.empty(K, dtype=float)

            for action in range(K):
                direct_mean = (
                    alpha[action]
                    / (alpha[action] + beta[action])
                )
                direct_var = (
                    direct_mean
                    * (1.0 - direct_mean)
                    / (
                        alpha[action]
                        + beta[action]
                        + 1.0
                    )
                )

                v_direct = max(
                    float(direct_var),
                    1e-10,
                )
                v_causal = max(
                    float(causal_var[action]),
                    1e-10,
                )

                combined_mean = (
                    causal_mean[action] / v_causal
                    + direct_mean / v_direct
                ) / (
                    1.0 / v_direct
                    + 1.0 / v_causal
                )

                combined_var = 1.0 / (
                    1.0 / v_direct
                    + 1.0 / v_causal
                )

                aa, bb = _beta_from_mean_variance(
                    float(combined_mean),
                    float(combined_var),
                )

                theta[action] = rng.beta(
                    aa,
                    bb,
                )

            action = _argmax_random_tie(
                theta,
                rng,
            )

            z, x, y = scm.sample(
                action,
                rng,
            )

            alpha[action] += y
            beta[action] += 1 - y

            causal.update(
                action,
                z,
                x,
                y,
            )

            cum_regret = _record_regret(
                cum_regret,
                action,
                means,
            )

            out[r, t] = cum_regret

        _print_progress(
            "Causal inverse-variance TS",
            r,
            trials,
        )

    return out




def run_causal_ts(
    scm: Task1SCM,
    trials: int,
    horizon: int,
    seed: int,
) -> np.ndarray:
    means = scm.arm_means()
    out = np.zeros((trials, horizon), dtype=float)

    for r in range(trials):
        rng = np.random.default_rng(seed + r)
        posterior = CPTPosterior()
        cum_regret = 0.0

        for t in range(horizon):
            sampled_means = posterior.sample_arm_means(rng, n=1)[0]
            action = _argmax_random_tie(sampled_means, rng)

            z, x, y = scm.sample(action, rng)
            posterior.update(action, z, x, y)

            cum_regret = _record_regret(cum_regret, action, means)
            out[r, t] = cum_regret

        _print_progress("Causal TS", r, trials)

    return out




def _mc_delta_and_information(mu_samples: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Monte-Carlo estimates of Delta_t(a) and g_t(a)=I(A*;Y_a).

    For each posterior draw theta_n:
      - A*_n = argmax_a mu_theta_n(a)
      - Y_a | theta_n ~ Bernoulli(mu_theta_n(a))

    The estimates are computed directly from posterior samples.
    """
    n, k = mu_samples.shape
    a_star = np.argmax(mu_samples, axis=1)
    best_mu = mu_samples[np.arange(n), a_star]

    delta = np.mean(best_mu[:, None] - mu_samples, axis=0)
    delta = np.clip(delta, 0.0, 1.0)

    p_star = np.bincount(a_star, minlength=k).astype(float) / n
    info = np.zeros(k, dtype=float)

    for action in range(k):
        mu_a = mu_samples[:, action]

        joint_y1 = (
            np.bincount(a_star, weights=mu_a, minlength=k).astype(float) / n
        )
        joint_y0 = p_star - joint_y1

        p_y1 = float(np.sum(joint_y1))
        p_y0 = 1.0 - p_y1

        g = 0.0
        for j in range(k):
            if p_star[j] <= 0.0:
                continue

            q1 = joint_y1[j]
            if q1 > 0.0 and p_y1 > 0.0:
                g += q1 * math.log(q1 / (p_star[j] * p_y1))

            q0 = joint_y0[j]
            if q0 > 0.0 and p_y0 > 0.0:
                g += q0 * math.log(q0 / (p_star[j] * p_y0))

        info[action] = max(g, 0.0)

    info = np.clip(info, 0.0, math.log(2.0))
    return delta, info


def _ids_ratio(regret: float, info: float) -> float:
    if regret <= 1e-15:
        return 0.0
    if info <= 1e-15:
        return math.inf
    return regret * regret / info


def _ids_distribution(delta: np.ndarray, info: np.ndarray) -> np.ndarray:
    """
    Minimize (pi^T Delta)^2/(pi^T g) over the simplex.

    For finite-action IDS, an optimum can be taken with support on at most two
    actions.  For every action pair we minimize the one-dimensional ratio
    analytically and compare the candidate interior point with the endpoints.
    """
    k = len(delta)
    best_ratio = math.inf
    best = None

    for i in range(k):
        r = _ids_ratio(float(delta[i]), float(info[i]))
        if r < best_ratio:
            best_ratio = r
            best = (i, i, 1.0)

        for j in range(i + 1, k):
            a = float(delta[i] - delta[j])
            b = float(delta[j])
            c = float(info[i] - info[j])
            d = float(info[j])

            candidates = [0.0, 1.0]

            if abs(a * c) > 1e-15:
                lam = (c * b - 2.0 * a * d) / (a * c)
                if 0.0 < lam < 1.0:
                    candidates.append(lam)

            if abs(a) > 1e-15:
                lam0 = -b / a
                if 0.0 < lam0 < 1.0:
                    candidates.append(lam0)

            for lam in candidates:
                reg = lam * delta[i] + (1.0 - lam) * delta[j]
                inf = lam * info[i] + (1.0 - lam) * info[j]
                r = _ids_ratio(float(reg), float(inf))
                if r < best_ratio:
                    best_ratio = r
                    best = (i, j, float(lam))

    if best is None or not np.isfinite(best_ratio):
        p = np.zeros(k, dtype=float)
        p[int(np.argmin(delta))] = 1.0
        return p

    i, j, lam = best
    p = np.zeros(k, dtype=float)
    p[i] += lam
    p[j] += 1.0 - lam
    p /= p.sum()
    return p


def run_ids(
    scm: Task1SCM,
    trials: int,
    horizon: int,
    seed: int,
    posterior_samples: int,
) -> np.ndarray:
    means = scm.arm_means()
    out = np.zeros((trials, horizon), dtype=float)

    for r in range(trials):
        rng = np.random.default_rng(seed + r)
        posterior = CPTPosterior()
        cum_regret = 0.0

        for t in range(horizon):
            mu_samples = posterior.sample_arm_means(rng, n=posterior_samples)
            delta_hat, info_hat = _mc_delta_and_information(mu_samples)
            pi = _ids_distribution(delta_hat, info_hat)

            action = int(rng.choice(K, p=pi))
            z, x, y = scm.sample(action, rng)
            posterior.update(action, z, x, y)

            cum_regret = _record_regret(cum_regret, action, means)
            out[r, t] = cum_regret

        _print_progress("IDS", r, trials)

    return out




def _plot_curve(
    ax,
    data: np.ndarray,
    label: str,
    color: str,
    marker: str,
    horizon: int,
) -> None:
    mean = np.mean(data, axis=0)
    sd = np.std(data, axis=0, ddof=1)
    se = sd / np.sqrt(data.shape[0])

    x = np.arange(1, horizon + 1)
    lower = np.maximum(0.0, mean - 1.96 * se)
    upper = mean + 1.96 * se

    mark_every = max(1, horizon // 10)
    ax.plot(
        x,
        mean,
        label=label,
        color=color,
        marker=marker,
        markevery=mark_every,
        markersize=6.5,
        linewidth=2.0,
        markeredgewidth=1.2,
        markerfacecolor="none" if marker not in ("*",) else color,
    )
    ax.fill_between(
        x,
        lower,
        upper,
        color=color,
        alpha=0.16,
        linewidth=0,
    )


def make_figure(results: dict, horizon: int) -> None:
    export_dpi = 600
    fig_width = 3200 / export_dpi
    fig_height = 2500 / export_dpi

    fig, ax = plt.subplots(
        figsize=(fig_width, fig_height),
        dpi=export_dpi,
    )

    _plot_curve(
        ax, results["ucb"], "UCB on POMISs", "#B33F40", "^", horizon
    )
    _plot_curve(
        ax,
        results["ts"],
        "Bernoulli TS on POMISs",
        "#0177B3",
        "s",
        horizon,
    )
    _plot_curve(
        ax,
        results["causal_baseline"],
        "Causal inverse-variance TS",
        "#0000CC",
        "*",
        horizon,
    )
    _plot_curve(
        ax,
        results["causal_ts"],
        "TS for Causal Bandits with Non-manipulable Variables",
        "#48A14D",
        "o",
        horizon,
    )
    _plot_curve(
        ax,
        results["ids"],
        "IDS for Causal Bandits with Non-manipulable Variables",
        "#D100D1",
        "D",
        horizon,
    )

    ax.set_xlim(0, horizon)
    ax.set_ylim(bottom=0)

    ax.set_xlabel("Time", fontsize=12.5)
    ax.set_ylabel("Mean Cumulative Regret", fontsize=12.5)
    ax.tick_params(
        axis="both",
        which="major",
        labelsize=10.5,
        width=1.0,
        length=4.0,
    )

    for spine in ax.spines.values():
        spine.set_linewidth(1.0)

    ax.grid(True, alpha=0.28, linewidth=0.7)

    ax.legend(
        fontsize=8.0,
        loc="upper left",
        frameon=True,
        framealpha=0.95,
        borderpad=0.6,
        labelspacing=0.45,
        handlelength=2.2,
        handletextpad=0.6,
    )

    fig.subplots_adjust(
        left=0.145,
        right=0.985,
        bottom=0.155,
        top=0.975,
    )

    output_file = "task1_fig3a.png"
    fig.savefig(
        output_file,
        dpi=export_dpi,
        facecolor="white",
        edgecolor="none",
    )
    print(f"Saved publication figure to: {output_file} (3200 x 2500 px, 600 dpi)")

    plt.show()




TRIALS = 500
HORIZON = 2000
IDS_SAMPLES = 1000

def main() -> None:
    if TRIALS < 2:
        raise ValueError("Use at least 2 trials so the confidence interval is defined.")
    if HORIZON < 1:
        raise ValueError("HORIZON must be positive")
    if IDS_SAMPLES < 1:
        raise ValueError("IDS_SAMPLES must be positive")

    scm = Task1SCM.fixed()
    true_means = scm.arm_means()

    print("Task 1: Z -> X -> Y and Z -> Y; Z is non-manipulable")
    print("SCM: fixed structured SCM shared by every method and trial")
    print(f"Trials: {TRIALS}, horizon: {HORIZON}")
    print(f"IDS posterior samples per round: {IDS_SAMPLES}")
    print(f"P(Z=1) = {scm.p_z1:.8f}")
    print(f"P(X=1|Z=0), P(X=1|Z=1) = {scm.p_x1_given_z}")
    print("P(Y=1|X=x,Z=z), rows x=0,1; columns z=0,1:")
    print(scm.p_y1_given_xz)
    print("True action means:")
    for name, mu in zip(ACTION_NAMES, true_means):
        print(f"  {name:10s}: {mu:.8f}")
    print(f"Optimal arm: {ACTION_NAMES[int(np.argmax(true_means))]}")
    print()

    results = {
        "ucb": run_ucb(scm, TRIALS, HORIZON, seed=1_000_000),
        "ts": run_bernoulli_ts(scm, TRIALS, HORIZON, seed=2_000_000),
        "causal_baseline": run_causal_inverse_variance_ts(
            scm,
            TRIALS,
            HORIZON,
            seed=3_000_000,
        ),
        "causal_ts": run_causal_ts(
            scm, TRIALS, HORIZON, seed=4_000_000
        ),
        "ids": run_ids(
            scm,
            TRIALS,
            HORIZON,
            seed=5_000_000,
            posterior_samples=IDS_SAMPLES,
        ),
    }

    make_figure(results, HORIZON)

    


if __name__ == "__main__":
    main()